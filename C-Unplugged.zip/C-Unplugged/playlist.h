#ifndef PLAYLIST_H
#define PLAYLIST_H
#include"album.h"
typedef struct node{
    char songna[100];
    struct node * next;
    struct node *prev;
}node;

void playfree();
void clearplaylist();
void insert(char str[]);
void insertlist(int n);
void printlist();
void printlistrev();
void deletesonginlist();
void playlist();
void addalbumtolist(album**head);


#endif