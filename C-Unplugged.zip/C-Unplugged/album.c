#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include"album.h"
#include"songs.h"
int id=67;
void idpull(){
    FILE *p;
    p=fopen("id.txt","r");
    fscanf(p,"%d",&id);
    fclose(p);
}
int albcount(char str[]){
    FILE*p=fopen(str,"r");
    char stt[100];
    int count=0;
    while(fscanf(p,"%s",stt)!=EOF){
        count++;
    }
    fclose(p);
    return count;
}
void intconverter(char str[],int n){
    int count=0;
    int x=n;
    while(x!=0){
        count++;
        x/=10;
    }
    x=count;
    while(n!=0){
        str[--count]=n%10+'0';
        n/=10;
    }
    str[x]='\0';
}
int checkalbdup(char str[],char albcheck[]){
    char check[100];
    FILE *p;
    p=fopen(albcheck,"r");
    if(p==NULL){
        return 0;
    }
    else{
    while(fscanf(p,"%s",check)!=EOF){
        if(strcmp(check,str)==0){
            fclose(p);
            return 1;
        }
    }
    fclose(p);
    return 0;
}
}
void createalbum(){
    char albname[100];
    char albnam1[100];
    FILE *p;
    FILE *idd;
    
    p=fopen("logs.txt","a");
    printf("Enter Album Name:");
    scanf("%s",albname);
    strcpy(albnam1,albname);
    strcpy(albname,"\0");
    intconverter(albname,id);
    strcat(albname,".txt");
    fprintf(p,"%s\n",albnam1);
    id++;
    idd=fopen("id.txt","w");
    fprintf(idd,"%d",id);
    fclose(idd);
    FILE *ptr;
    ptr=fopen(albname,"r");
    if(ptr!=NULL){
        fclose(ptr);
        printf("An Album with the same name already exists.\n");
    }
    else{
        ptr=fopen(albname,"a");
        fclose(ptr);
        printf("Album %s created.\n",albnam1);
        FILE *p;
        p=fopen("albumlist.txt","a");
        fprintf(p,"%s %s\n",albnam1,albname);
        fclose(p);
    }
    fclose(p);
    
}
void albfree(album **head){
    album *temp=*head;
    album *upcm;
    while(temp!=NULL){
        upcm=temp->next;
        free(temp);
        temp=upcm;
    }
    *head=NULL;
}
int albumslist(){
    char str [100];
    char str2[100];
    FILE *ff;
    ff=fopen("albumlist.txt","r");
    int i=1;
    if(ff==NULL){
        printf("0 Albums created.\n");

        return -1;
    }
    
    while(1){
    if(fscanf(ff,"%s",str)==EOF){break;}
    printf("%d.%s\n",i,str);
    fscanf(ff,"%s",str2);
    i++;
    }
    fclose(ff);
    return id-67;
}
void addsongalbum(album **head, int n)
{
    int lim=id-67;
    int k;
    char albname[100];
    char albnam1[100];
    FILE *p;
    p=fopen("logs.txt","a");
    int c=albumslist();
    if(c==-1){
        fclose(p);
        return;
    }
    printf("Enter Album index number:");
    scanf("%d",&k);
    fprintf(p,"%d\n",k);
    if(k<1||k>lim){
        printf("Invalid Index.\n");
        fclose(p);
        return;
    }
    FILE *ppp;
    ppp=fopen("albumlist.txt","r");
    for(int i=0;i<k;i++){
        fscanf(ppp,"%s",albnam1);
        fscanf(ppp,"%s",albname);
    }
    fclose(ppp);
    // strcpy(albnam1,albname);
    // strcat(albname,".txt");
    albfree(head);
    datapullalbum(head,albname);
    if(*head==NULL){
        FILE *pr;
        pr=fopen(albname,"r");
        if(pr==NULL){
        printf("Album %s does not exist.Creating a new one\n",albnam1);
        FILE *ff;
        ff=fopen("albumlist.txt","a");
        fprintf(ff,"%s\n",albnam1);
        fclose(ff);
        }
        else{
            fclose(pr);
        }
    }
    FILE *ptr;
    ptr = fopen(albname, "a");

    album *newnode = malloc(sizeof(album));
    song(newnode->songname, n);
    newnode->next = NULL;
    if(checkalbdup(newnode->songname,albname)){
        printf("Selected song already exists in the Album %s.\n",albnam1);
        free(newnode);
        fclose(ptr);
        fclose(p);
        return;
    }
    fprintf(ptr, "%s\n", newnode->songname);

    if (*head == NULL)
    {
        *head = newnode;
        fclose(ptr);
        fclose(p);
        printf("Album Updated.\n");
        return;
    }
    album *temp = *head;
    while (temp->next != NULL)
    {
        temp = temp->next;
    }
    temp->next = newnode;
    printf("Album Updated.\n");
    fclose(ptr);
    fclose(p);
}
void deletesongalbum(album **head)
{
    int lim=id-67;
    char albname[100];
    int k;
    char albnam1[100];
    FILE *p;
    if(lim==0){
        return;
    }
    p=fopen("logs.txt","a");
    printf("Enter Album index number:");
    scanf("%d",&k);
    fprintf(p,"%d\n",k);
    if(k>lim || k<1){
        printf("Invalid Index.\n");
        fclose(p);
        return;
    }
    FILE *ppp;
    ppp=fopen("albumlist.txt","r");
    for(int i=0;i<k;i++){
        fscanf(ppp,"%s",albnam1);
        fscanf(ppp,"%s",albname);
    }
    fclose(ppp);
    // fprintf(p,"%s\n",albname);
    // strcpy(albnam1,albname);
    // strcat(albname,".txt");
    albfree(head);
    datapullalbum(head,albname);
    album *t=*head;
    int i=1;
    while(t!=NULL){
        printf("%d.%s\n",i,t->songname);
        t=t->next;
        i++;
    }
    
    if(*head==NULL){
        FILE *pr;
        pr=fopen(albname,"r");
        if(pr==NULL){
        printf("Album %s does not exist.\n",albnam1);
        fclose(p);
        return;
        }
        else{
            char st[100];
            if(fscanf(pr,"%s",st)==EOF){
            printf("Album %s is empty\n",albnam1);
            fclose(pr);
            fclose(p);
            return;
            }
        }
    }
    int limalbum=albcount(albname);
    printf("Enter Index of Song to delete:");
    int n;
    scanf("%d",&n);
    fprintf(p,"%d\n",n);
    if(n<1 || n>limalbum){
        printf("Invalid Index.\n");
        fclose(p);
        return;
    }
    album *temp = *head;
    album *prev = NULL;
    for (int i = 1; i < n; i++)
    {
        prev = temp;
        temp = prev->next;
    }
    if(prev==NULL){
        *head=temp->next;
        free(temp);
        
        album *temp1 = *head;
        FILE *ptr;
        ptr = fopen(albname,"w");
        while (temp1 != NULL)
        {
        fprintf(ptr, "%s\n", temp1->songname);
        temp1 = temp1->next;
        }
        fclose(ptr);
        printf("Album Updated.\n");
        fclose(p);
        return;
    }
    prev->next = temp->next;
    free(temp);
    album *temp1 = *head;
    FILE *ptr;
    ptr = fopen(albname,"w");
    while (temp1 != NULL)
    {
        fprintf(ptr, "%s\n", temp1->songname);
        temp1 = temp1->next;
    }
    fclose(ptr);
    printf("Album Updated.\n");
    fclose(p);
}
void printalbum(album **head)
{
    int lim=id-67;
    char albnam1[100];
    char albname[100];
    int k;
    FILE *p;
    if(lim==0){
        printf("0 Albums created.\n");
        return;
    }
    p=fopen("logs.txt","a");
    albumslist();
    printf("Enter Album index number:");
    scanf("%d",&k);
    fprintf(p,"%d\n",k);
    if(k>lim || k<1){
        printf("Invalid Index.\n");
        fclose(p);
        return;
    }
    FILE *ppp;
    ppp=fopen("albumlist.txt","r");
    for(int i=0;i<k;i++){
        fscanf(ppp,"%s",albnam1);
        fscanf(ppp,"%s",albname);
    }
    fclose(ppp);
    // fprintf(p,"%s\n",albname);
    // strcpy(albnam1,albname);
    // strcat(albname,".txt");
    albfree(head);
    datapullalbum(head,albname);
    if(*head==NULL){
        FILE *pr;
        pr=fopen(albname,"r");
        if(pr==NULL){
        printf("Album %s does not exist.\n",albnam1);
        fclose(p);
        return;
        }
        else{
            char st[100];
            if(fscanf(pr,"%s",st)==EOF){
            printf("Album %s is empty\n",albnam1);
            fclose(p);
            fclose(pr);
            return;
            }
        }
    }
    album *temp = *head;
    int i=1;
    while (temp != NULL)
    {
        printf("%d.%s\n",i, temp->songname);
        temp = temp->next;
        i++;
    }
    fclose(p);
}
void datapullinsert(char str[], album **head)
{
    album *newnode = malloc(sizeof(album));
    strcpy(newnode->songname, str);
    newnode->next = NULL;
    if (*head == NULL)
    {
        *head = newnode;
        return;
    }
    album *temp = *head;
    while (temp->next != NULL)
    {
        temp = temp->next;
    }
    temp->next = newnode;
}
void datapullalbum(album **head,char albname[])
{
    // char albname[100];
    // scanf("%s",albname);
    // strcat(albname,".txt");
    FILE *ptr;
    ptr = fopen(albname, "r");
    if (ptr == NULL)
    {
       
        return;
    }
    char str[100];
    while (fscanf(ptr,"%s",str) != EOF)
    {
        datapullinsert(str,head);
    }
    fclose(ptr);
}
