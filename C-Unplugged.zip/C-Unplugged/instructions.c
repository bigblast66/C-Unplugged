#include <stdio.h>
#include "instructions.h"

void instructions() {
    printf("\nC-Unplugged\n");
    printf("-----------\n");
    printf("Number         : Description\n");
    printf("----------------------------------------------\n");
    printf("1              : list all songs in the library\n");
    printf("2              : show this help again\n");
    printf("3              : quit the application\n");

    printf("\nAlbum Commands\n");
    printf("--------------\n");
    printf("Number         : Description\n");
    printf("----------------------------------------------\n");
    printf("4              : show all albums\n");
    printf("5              : create an empty album\n");
    printf("6              : add a song from the library to an album\n");
    printf("7              : show songs inside an album\n");
    printf("8              : delete a song from an album\n");

    printf("\nPlaylist Commands\n");
    printf("-----------------\n");
    printf("Number         : Description\n");
    printf("----------------------------------------------\n");
    printf("9              : add a song from the library to the playlist\n");
    printf("10             : add all songs of an album to the playlist\n");
    printf("11             : show songs in the playlist\n");
    printf("12             : delete a song from the playlist\n");
    printf("13             : empties full playlist\n");
    printf("14             : play the playlist from the start\n");
    printf("\nLog Commands\n");
    printf("-----------------\n");
    printf("Number         : Description\n");
    printf("15             : view logs of user\n");
}

