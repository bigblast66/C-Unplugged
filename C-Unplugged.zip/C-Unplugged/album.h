#ifndef ALBUM_H
#define ALBUM_H

typedef struct album
{
    char songname[100];
    
    struct album *next;
} album;
// int checkalbdup(char str[]);
void idpull();
void createalbum();
void albfree(album **head);
int albumslist();
void addsongalbum(album **head, int n);
void deletesongalbum(album **head);
void printalbum(album **head);
void datapullinsert(char str[], album **head);
void datapullalbum(album **head,char albname[]);


#endif
