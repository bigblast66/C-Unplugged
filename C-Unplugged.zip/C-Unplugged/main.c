#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "songs.h"
#include "album.h"
#include "playlist.h"
#include "instructions.h"
void viewlogs(){
    char str[100];
    FILE *p;
    p=fopen("logs.txt","r");
    while(fgets(str,sizeof(str),p)!=NULL){
        printf("%s",str);
    }
    fclose(p);
}
int main()
{
    album *head1=NULL;
    
    FILE *p;
    printf("====================================\n");
    printf("🎵     Welcome to C-Unplugged     🎵\n");
    printf("====================================\n");
    char cmd[100];
    cmd[0]='\0';
    p=fopen("logs.txt","a");
    fprintf(p,"%s\n","----session start----");
    instructions();

    while(1){
        // instructions();
        scanf("%s",cmd);
        idpull();
        fprintf(p,"%s\n",cmd);

        if(strcmp(cmd,"3")==0){
            break;
        }
        if(strcmp(cmd,"1")==0){
            listsong();
        }
        if(strcmp(cmd,"2")==0){
            instructions();
        }
       
        if(strcmp(cmd,"7")==0){
            fclose(p);
            printalbum(&head1);
            p=fopen("logs.txt","a");
        }
        if(strcmp(cmd,"6")==0){
            listsong();
            printf("Enter Index of Song to add:");
            int n;
            scanf("%d",&n);
            fprintf(p,"%d\n",n);
            if(n<=50 && n>0){
            fclose(p);
            addsongalbum(&head1,n);
            p=fopen("logs.txt","a");
            }
            else{
                printf("Invalid Index.\n");
            }
        }
        if(strcmp(cmd,"8")==0){
            fclose(p);
            albumslist();
            deletesongalbum(&head1);
            p=fopen("logs.txt","a");
        }
        if(strcmp(cmd,"4")==0){
            albumslist();
        }
        
        if(strcmp(cmd,"9")==0){
            listsong();
            printf("Enter Index of Song to add:");
            int n;
            scanf("%d",&n);
            fprintf(p,"%d\n",n);
            if(n<=50 && n>0){
            insertlist(n);
            }
            else{
                printf("Invalid Index.\n");
            }
        }
        if(strcmp(cmd,"12")==0){
            fclose(p);
            deletesonginlist();
            p=fopen("logs.txt","a");
        }
        if(strcmp(cmd,"11")==0){
            printlist();
        }
        if(strcmp(cmd,"14")==0){
            fclose(p);
            playlist();
            p=fopen("logs.txt","a");
        }
        if(strcmp(cmd,"10")==0){
            fclose(p);
            addalbumtolist(&head1);
            p=fopen("logs.txt","a");
        }
        if(strcmp(cmd,"5")==0){
            fclose(p);
            createalbum();
            p=fopen("logs.txt","a");
        }
        if(strcmp(cmd,"13")==0){
            clearplaylist();
        }
        if(strcmp(cmd,"15")==0){
            fclose(p);
            viewlogs();
            p=fopen("logs.txt","a");
        }
    }

    printf("Exited Unplugged Successfully.\n");
    albfree(&head1);
    playfree();
    fprintf(p,"%s\n","----session end----");
    fclose(p);
}
