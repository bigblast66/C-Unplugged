#include <stdio.h>
#include <string.h>
#include <stdlib.h>
void listsong()
{
    FILE *ptr;
    ptr = fopen("music.txt", "r");
    int l, y;
    char str1[30], str2[30], str3[30];
    int i = 1;
    while (fscanf(ptr, "%s %s %d %s %d", str1, str2, &y, str3, &l) != EOF)
    {
        printf("%d.Name:%s Artist:%s Year:%d Genre:%s Length:%ds\n", i, str1, str2, y, str3, l);
        i++;
    }
    fclose(ptr);
}
void song(char song[], int n)
{
    FILE *fptr;
    int l, y;
    char str1[30], str2[30], str3[30];
    fptr = fopen("music.txt", "r");
    int i = 1;
    fscanf(fptr, "%s %s %d %s %d", str1, str2, &y, str3, &l);
    while (i < n)
    {
        fscanf(fptr, "%s %s %d %s %d", str1, str2, &y, str3, &l);
        i++;
    }
    strcpy(song, str1);
    fclose(fptr);
}
