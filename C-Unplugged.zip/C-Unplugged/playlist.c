#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include"playlist.h"
#include"album.h"
#include"songs.h"

node *head=NULL;
node *tail=NULL;
node *traverse=NULL;
int playcount=0;
void playfree(){
    node *temp=head;
    node *upcm;
    while(temp!=NULL){
        upcm=temp->next;
        free(temp);
        temp=upcm;
    }
    head=NULL;
    tail=NULL;
    traverse=NULL;
}
void clearplaylist(){
    
    if(head==NULL){
        printf("The playlist is already empty.\n");
        return;
    }
    playfree();
    printf("The Playlist has been cleared.\n");
    
}
void insert(char str[]){
    node *newnode=malloc(sizeof(node));
    newnode->next=NULL;
    newnode->prev=NULL;
    strcpy(newnode->songna,str);
    if(head==NULL){
        head=newnode;
        tail=newnode;
        playcount++;
        return;
    }
    node *temp=head;
    while(temp->next!=NULL){
        temp=temp->next;
    }
    temp->next=newnode;
    newnode->prev=temp;
    tail=newnode;
    playcount++;
}
void insertlist(int n){
    char str[100];
    song(str,n);
    insert(str);
    
    printf("Added successfully.\n");
}
void printlist(){
    node *temp=head;
    if(head==NULL){
        printf("The playlist is currently empty.\n");
        return;
    }
    int i=1;
    while(temp!=NULL){
        printf("%d.%s\n",i,temp->songna);
        temp=temp->next;
        i++;
    }
}
void printlistrev(){
    node *temp=tail;
    while(temp!=NULL){
        printf("%s\n",temp->songna);
        temp=temp->prev;
    }
}
void deletesonginlist(){
    node *temp=head;
    node *prev=NULL;
    if (head == NULL) {
        printf("The playlist is empty.No songs to delete.\n");
        return;
    }
    printlist();
    FILE *pp;
    pp=fopen("logs.txt","a");
    int n;
    printf("Enter Index of Song to delete:");
    scanf("%d",&n);
    fprintf(pp,"%d",n);
    if(n<1 || n>playcount){
        printf("Invalid Index.\n");
        fclose(pp);
        return;
    }
    for(int i=1;i<n;i++){
        prev=temp;
        temp=temp->next;
    }
    
    
    
    fprintf(pp,"%d\n",n);
    if(prev==NULL){
        if(head->next==NULL){
            head=head->next;
            tail=NULL;
            free(temp);
             printf("Deleted successfully.\n");
             fclose(pp);
             playcount--;
            return;
        }
        head->next->prev=NULL;
        head=head->next;
        free(temp);
         printf("Deleted successfully.\n");
         fclose(pp);
         playcount--;
        return;
    }
    if(temp->next==NULL){
        tail->prev->next=NULL;
        tail=tail->prev;
        free(temp);
         printf("Deleted successfully.\n");
         fclose(pp);
         playcount--;
        return;
    }
    temp->next->prev=prev;
    prev->next=temp->next;
    free(temp);
    fclose(pp);
    printf("Deleted successfully.\n");
    playcount--;
}
void playlist(){
    FILE *p;
    if(head==NULL){
        printf("🎧 The playlist is empty. Nothing to play.\n");
        return;
    }
   printf("\n=============================================\n");
    printf("               🎵 PLAYLIST MODE 🎵\n");
    printf("=============================================\n");
    printf("Commands:\n");
    printf("  1       → play next song\n");
    printf("  2       → play previous song\n");
    printf("  3       → stop playback and exit\n");
    printf("---------------------------------------------\n");
    char str[100];
    str[0]='\0';
    traverse=head;
    p=fopen("logs.txt","a");
    printf("Now Playing: %s\n",traverse->songna);
    while(strcmp("3",str)!=0){
        printf("Enter command (1 / 2 / 3):");
        scanf("%s",str);
        
        fprintf(p,"%s\n",str);


        if(strcmp(str,"1")==0){
            if(traverse->next==NULL){
                traverse=head;
            }
            else{
            traverse=traverse->next;
            }
            printf("Now Playing: %s\n",traverse->songna);
        }
        if(strcmp(str,"2")==0){
            if(traverse->prev==NULL){
                traverse=tail;
            }
            else{
            traverse=traverse->prev;
            }
            printf("Now Playing: %s\n",traverse->songna);
        }
        
    }
    printf("Playlist stopped.Returning to main menu.\n");
    fclose(p);

}
void addalbumtolist(album**head){
    char albname[100];
    char albnam1[100];
    int k;
    FILE *p;
    p=fopen("logs.txt","a");
    int c=albumslist();
    if(c==-1){
        fclose(p);
        return;
    }
    printf("Enter Album index number:");
    scanf("%d",&k);
    fprintf(p,"%d\n",k);
    if(k<1 ||k>c){
        printf("Invalid Index.\n");
        fclose(p);
        return;
    }
    FILE *ppp;
    ppp=fopen("albumlist.txt","r");
    for(int i=0;i<k;i++){
        fscanf(ppp,"%s",albnam1);
        fscanf(ppp,"%s",albname);
    }
    fclose(ppp);
    // strcpy(albnam1,albname);
    // strcat(albname,".txt");
    albfree(head);
    datapullalbum(head,albname);
    if(*head==NULL){
        FILE *pr;
        pr=fopen(albname,"r");
        if(pr==NULL){
        printf("Album %s does not exist.\n",albnam1);
        fclose(p);
        return;
        }
        else{
            char st[100];
            if(fscanf(pr,"%s",st)==EOF){
            printf("Album %s is empty.\n",albnam1);
            fclose(pr);
            fclose(p);
            return;
            }
        }
    }
    album *temp=*head;
    while(temp!=NULL){
        insert(temp->songname);
        temp=temp->next;
    }
    printf("Successfully added songs from %s to your playlist.\n",albnam1);
    fclose(p);
}
