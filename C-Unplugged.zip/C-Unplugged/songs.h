#ifndef SONGS_H
#define SONGS_H

void listsong();
void song(char song[], int n);


#endif